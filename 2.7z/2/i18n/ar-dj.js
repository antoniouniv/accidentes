require('./angular-locale_ar-dj');
module.exports = 'ngLocale';
