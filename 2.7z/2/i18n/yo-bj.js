require('./angular-locale_yo-bj');
module.exports = 'ngLocale';
