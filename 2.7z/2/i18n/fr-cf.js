require('./angular-locale_fr-cf');
module.exports = 'ngLocale';
