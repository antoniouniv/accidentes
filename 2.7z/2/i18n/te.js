require('./angular-locale_te');
module.exports = 'ngLocale';
