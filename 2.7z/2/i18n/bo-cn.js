require('./angular-locale_bo-cn');
module.exports = 'ngLocale';
