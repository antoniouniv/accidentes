require('./angular-locale_ha-latn-ng');
module.exports = 'ngLocale';
