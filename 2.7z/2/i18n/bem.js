require('./angular-locale_bem');
module.exports = 'ngLocale';
