require('./angular-locale_ce-ru');
module.exports = 'ngLocale';
