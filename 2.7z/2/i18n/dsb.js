require('./angular-locale_dsb');
module.exports = 'ngLocale';
