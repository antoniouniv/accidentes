require('./angular-locale_sr-latn-rs');
module.exports = 'ngLocale';
