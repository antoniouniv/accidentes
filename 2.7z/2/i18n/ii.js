require('./angular-locale_ii');
module.exports = 'ngLocale';
