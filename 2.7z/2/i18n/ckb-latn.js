require('./angular-locale_ckb-latn');
module.exports = 'ngLocale';
