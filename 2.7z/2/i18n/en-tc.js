require('./angular-locale_en-tc');
module.exports = 'ngLocale';
