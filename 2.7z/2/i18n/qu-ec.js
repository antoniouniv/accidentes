require('./angular-locale_qu-ec');
module.exports = 'ngLocale';
