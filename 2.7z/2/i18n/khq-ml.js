require('./angular-locale_khq-ml');
module.exports = 'ngLocale';
