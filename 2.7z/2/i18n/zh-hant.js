require('./angular-locale_zh-hant');
module.exports = 'ngLocale';
