require('./angular-locale_pt-mz');
module.exports = 'ngLocale';
