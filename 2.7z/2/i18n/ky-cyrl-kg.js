require('./angular-locale_ky-cyrl-kg');
module.exports = 'ngLocale';
