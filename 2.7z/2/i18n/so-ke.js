require('./angular-locale_so-ke');
module.exports = 'ngLocale';
