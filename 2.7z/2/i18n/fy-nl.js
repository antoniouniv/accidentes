require('./angular-locale_fy-nl');
module.exports = 'ngLocale';
