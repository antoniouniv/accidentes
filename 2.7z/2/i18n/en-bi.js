require('./angular-locale_en-bi');
module.exports = 'ngLocale';
