require('./angular-locale_fr-ga');
module.exports = 'ngLocale';
