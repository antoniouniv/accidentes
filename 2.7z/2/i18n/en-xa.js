require('./angular-locale_en-xa');
module.exports = 'ngLocale';
