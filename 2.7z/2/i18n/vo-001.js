require('./angular-locale_vo-001');
module.exports = 'ngLocale';
