require('./angular-locale_fr-mq');
module.exports = 'ngLocale';
