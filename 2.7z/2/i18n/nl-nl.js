require('./angular-locale_nl-nl');
module.exports = 'ngLocale';
