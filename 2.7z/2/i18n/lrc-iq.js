require('./angular-locale_lrc-iq');
module.exports = 'ngLocale';
