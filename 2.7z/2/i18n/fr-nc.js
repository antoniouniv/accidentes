require('./angular-locale_fr-nc');
module.exports = 'ngLocale';
