require('./angular-locale_is');
module.exports = 'ngLocale';
