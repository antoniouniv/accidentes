require('./angular-locale_mua-cm');
module.exports = 'ngLocale';
