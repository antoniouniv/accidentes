require('./angular-locale_ks-in');
module.exports = 'ngLocale';
