require('./angular-locale_ug-arab-cn');
module.exports = 'ngLocale';
