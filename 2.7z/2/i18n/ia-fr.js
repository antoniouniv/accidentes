require('./angular-locale_ia-fr');
module.exports = 'ngLocale';
