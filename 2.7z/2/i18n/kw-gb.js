require('./angular-locale_kw-gb');
module.exports = 'ngLocale';
