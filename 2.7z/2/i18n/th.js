require('./angular-locale_th');
module.exports = 'ngLocale';
