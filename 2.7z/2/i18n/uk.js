require('./angular-locale_uk');
module.exports = 'ngLocale';
