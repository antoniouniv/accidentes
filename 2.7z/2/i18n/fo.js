require('./angular-locale_fo');
module.exports = 'ngLocale';
