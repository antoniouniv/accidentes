require('./angular-locale_en-cx');
module.exports = 'ngLocale';
