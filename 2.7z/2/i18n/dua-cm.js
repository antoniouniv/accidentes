require('./angular-locale_dua-cm');
module.exports = 'ngLocale';
