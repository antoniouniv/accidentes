require('./angular-locale_nl-be');
module.exports = 'ngLocale';
