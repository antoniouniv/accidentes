require('./angular-locale_hy-am');
module.exports = 'ngLocale';
