require('./angular-locale_fr-bl');
module.exports = 'ngLocale';
