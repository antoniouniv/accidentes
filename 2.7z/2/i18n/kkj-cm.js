require('./angular-locale_kkj-cm');
module.exports = 'ngLocale';
