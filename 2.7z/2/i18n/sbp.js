require('./angular-locale_sbp');
module.exports = 'ngLocale';
