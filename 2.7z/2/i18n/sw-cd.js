require('./angular-locale_sw-cd');
module.exports = 'ngLocale';
