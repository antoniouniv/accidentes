require('./angular-locale_en-nl');
module.exports = 'ngLocale';
