require('./angular-locale_ssy-er');
module.exports = 'ngLocale';
