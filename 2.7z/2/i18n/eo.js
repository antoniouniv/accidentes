require('./angular-locale_eo');
module.exports = 'ngLocale';
