require('./angular-locale_kab-dz');
module.exports = 'ngLocale';
