require('./angular-locale_se');
module.exports = 'ngLocale';
