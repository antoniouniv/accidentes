require('./angular-locale_tzm-ma');
module.exports = 'ngLocale';
