require('./angular-locale_ff');
module.exports = 'ngLocale';
