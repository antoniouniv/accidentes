require('./angular-locale_ru-ru');
module.exports = 'ngLocale';
