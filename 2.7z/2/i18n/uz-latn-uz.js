require('./angular-locale_uz-latn-uz');
module.exports = 'ngLocale';
