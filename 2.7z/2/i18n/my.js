require('./angular-locale_my');
module.exports = 'ngLocale';
