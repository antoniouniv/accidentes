require('./angular-locale_fr-dz');
module.exports = 'ngLocale';
