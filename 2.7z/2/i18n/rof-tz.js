require('./angular-locale_rof-tz');
module.exports = 'ngLocale';
