require('./angular-locale_sl-si');
module.exports = 'ngLocale';
