require('./angular-locale_pt-gq');
module.exports = 'ngLocale';
