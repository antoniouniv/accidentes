require('./angular-locale_da-gl');
module.exports = 'ngLocale';
