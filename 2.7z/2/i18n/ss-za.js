require('./angular-locale_ss-za');
module.exports = 'ngLocale';
