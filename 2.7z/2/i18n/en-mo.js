require('./angular-locale_en-mo');
module.exports = 'ngLocale';
