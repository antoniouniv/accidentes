require('./angular-locale_nnh');
module.exports = 'ngLocale';
