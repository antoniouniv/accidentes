require('./angular-locale_no-no');
module.exports = 'ngLocale';
