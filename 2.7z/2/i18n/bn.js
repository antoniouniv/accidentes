require('./angular-locale_bn');
module.exports = 'ngLocale';
