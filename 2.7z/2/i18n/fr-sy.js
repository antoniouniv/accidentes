require('./angular-locale_fr-sy');
module.exports = 'ngLocale';
