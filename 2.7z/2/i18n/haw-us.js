require('./angular-locale_haw-us');
module.exports = 'ngLocale';
