require('./angular-locale_fr-tg');
module.exports = 'ngLocale';
