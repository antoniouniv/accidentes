require('./angular-locale_en-de');
module.exports = 'ngLocale';
