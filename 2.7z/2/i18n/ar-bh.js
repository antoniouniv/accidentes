require('./angular-locale_ar-bh');
module.exports = 'ngLocale';
