require('./angular-locale_fr-cm');
module.exports = 'ngLocale';
