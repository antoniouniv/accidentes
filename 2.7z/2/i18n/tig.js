require('./angular-locale_tig');
module.exports = 'ngLocale';
