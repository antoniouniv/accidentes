require('./angular-locale_asa');
module.exports = 'ngLocale';
