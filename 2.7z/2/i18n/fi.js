require('./angular-locale_fi');
module.exports = 'ngLocale';
