require('./angular-locale_en-gu');
module.exports = 'ngLocale';
