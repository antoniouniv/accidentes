require('./angular-locale_nd-zw');
module.exports = 'ngLocale';
