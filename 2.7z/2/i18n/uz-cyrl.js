require('./angular-locale_uz-cyrl');
module.exports = 'ngLocale';
