require('./angular-locale_seh');
module.exports = 'ngLocale';
