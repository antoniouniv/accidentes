require('./angular-locale_ar-il');
module.exports = 'ngLocale';
