require('./angular-locale_rwk');
module.exports = 'ngLocale';
