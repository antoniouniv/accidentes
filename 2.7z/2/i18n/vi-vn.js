require('./angular-locale_vi-vn');
module.exports = 'ngLocale';
