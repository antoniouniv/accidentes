require('./angular-locale_en-gh');
module.exports = 'ngLocale';
