require('./angular-locale_zh-hant-hk');
module.exports = 'ngLocale';
