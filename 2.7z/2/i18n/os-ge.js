require('./angular-locale_os-ge');
module.exports = 'ngLocale';
