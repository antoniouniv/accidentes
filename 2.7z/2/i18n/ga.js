require('./angular-locale_ga');
module.exports = 'ngLocale';
