require('./angular-locale_bg-bg');
module.exports = 'ngLocale';
