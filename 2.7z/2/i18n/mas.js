require('./angular-locale_mas');
module.exports = 'ngLocale';
