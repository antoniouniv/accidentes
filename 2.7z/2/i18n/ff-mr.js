require('./angular-locale_ff-mr');
module.exports = 'ngLocale';
