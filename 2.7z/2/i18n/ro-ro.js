require('./angular-locale_ro-ro');
module.exports = 'ngLocale';
