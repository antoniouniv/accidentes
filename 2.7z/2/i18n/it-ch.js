require('./angular-locale_it-ch');
module.exports = 'ngLocale';
