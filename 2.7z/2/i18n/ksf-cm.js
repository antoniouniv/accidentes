require('./angular-locale_ksf-cm');
module.exports = 'ngLocale';
