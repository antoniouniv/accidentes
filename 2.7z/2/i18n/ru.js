require('./angular-locale_ru');
module.exports = 'ngLocale';
