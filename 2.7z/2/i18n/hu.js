require('./angular-locale_hu');
module.exports = 'ngLocale';
