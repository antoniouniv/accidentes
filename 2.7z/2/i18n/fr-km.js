require('./angular-locale_fr-km');
module.exports = 'ngLocale';
