require('./angular-locale_en-pk');
module.exports = 'ngLocale';
