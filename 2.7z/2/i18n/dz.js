require('./angular-locale_dz');
module.exports = 'ngLocale';
