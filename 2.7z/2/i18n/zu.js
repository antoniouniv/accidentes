require('./angular-locale_zu');
module.exports = 'ngLocale';
