require('./angular-locale_en-gy');
module.exports = 'ngLocale';
