require('./angular-locale_nl-cw');
module.exports = 'ngLocale';
