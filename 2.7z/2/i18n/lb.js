require('./angular-locale_lb');
module.exports = 'ngLocale';
