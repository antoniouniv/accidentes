require('./angular-locale_sr');
module.exports = 'ngLocale';
