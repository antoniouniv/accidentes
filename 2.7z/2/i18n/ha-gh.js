require('./angular-locale_ha-gh');
module.exports = 'ngLocale';
