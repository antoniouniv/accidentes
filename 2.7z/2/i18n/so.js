require('./angular-locale_so');
module.exports = 'ngLocale';
