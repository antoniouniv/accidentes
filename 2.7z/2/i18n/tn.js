require('./angular-locale_tn');
module.exports = 'ngLocale';
