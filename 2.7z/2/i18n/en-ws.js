require('./angular-locale_en-ws');
module.exports = 'ngLocale';
