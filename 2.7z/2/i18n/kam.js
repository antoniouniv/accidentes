require('./angular-locale_kam');
module.exports = 'ngLocale';
