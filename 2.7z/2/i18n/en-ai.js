require('./angular-locale_en-ai');
module.exports = 'ngLocale';
