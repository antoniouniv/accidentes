require('./angular-locale_mr');
module.exports = 'ngLocale';
