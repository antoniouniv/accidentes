require('./angular-locale_as-in');
module.exports = 'ngLocale';
