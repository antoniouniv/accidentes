require('./angular-locale_ewo');
module.exports = 'ngLocale';
