require('./angular-locale_en-io');
module.exports = 'ngLocale';
