require('./angular-locale_sv-ax');
module.exports = 'ngLocale';
