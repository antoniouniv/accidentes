require('./angular-locale_ia');
module.exports = 'ngLocale';
