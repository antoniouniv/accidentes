require('./angular-locale_byn-er');
module.exports = 'ngLocale';
