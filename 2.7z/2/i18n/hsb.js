require('./angular-locale_hsb');
module.exports = 'ngLocale';
