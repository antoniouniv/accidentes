require('./angular-locale_es');
module.exports = 'ngLocale';
