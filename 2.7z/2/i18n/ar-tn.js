require('./angular-locale_ar-tn');
module.exports = 'ngLocale';
