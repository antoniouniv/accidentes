require('./angular-locale_swc');
module.exports = 'ngLocale';
