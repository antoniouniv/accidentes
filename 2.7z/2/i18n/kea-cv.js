require('./angular-locale_kea-cv');
module.exports = 'ngLocale';
