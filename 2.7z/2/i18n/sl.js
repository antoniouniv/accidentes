require('./angular-locale_sl');
module.exports = 'ngLocale';
