require('./angular-locale_en-um');
module.exports = 'ngLocale';
