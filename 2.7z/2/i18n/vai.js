require('./angular-locale_vai');
module.exports = 'ngLocale';
