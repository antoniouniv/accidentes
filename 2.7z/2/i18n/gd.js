require('./angular-locale_gd');
module.exports = 'ngLocale';
