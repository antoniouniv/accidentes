require('./angular-locale_ast-es');
module.exports = 'ngLocale';
