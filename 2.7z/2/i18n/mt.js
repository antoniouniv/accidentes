require('./angular-locale_mt');
module.exports = 'ngLocale';
