require('./angular-locale_en-nz');
module.exports = 'ngLocale';
