require('./angular-locale_bem-zm');
module.exports = 'ngLocale';
