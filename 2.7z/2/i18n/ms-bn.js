require('./angular-locale_ms-bn');
module.exports = 'ngLocale';
