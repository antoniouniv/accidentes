require('./angular-locale_pt-ch');
module.exports = 'ngLocale';
