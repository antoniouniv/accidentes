require('./angular-locale_shi-latn');
module.exports = 'ngLocale';
