require('./angular-locale_es-co');
module.exports = 'ngLocale';
