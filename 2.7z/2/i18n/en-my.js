require('./angular-locale_en-my');
module.exports = 'ngLocale';
