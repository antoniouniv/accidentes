require('./angular-locale_id');
module.exports = 'ngLocale';
