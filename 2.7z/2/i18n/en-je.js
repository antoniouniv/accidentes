require('./angular-locale_en-je');
module.exports = 'ngLocale';
