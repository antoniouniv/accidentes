require('./angular-locale_es-uy');
module.exports = 'ngLocale';
