require('./angular-locale_yi');
module.exports = 'ngLocale';
