require('./angular-locale_mk');
module.exports = 'ngLocale';
