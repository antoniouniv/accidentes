require('./angular-locale_zh-hans-cn');
module.exports = 'ngLocale';
