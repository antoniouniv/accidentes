require('./angular-locale_ts');
module.exports = 'ngLocale';
