require('./angular-locale_sw-tz');
module.exports = 'ngLocale';
