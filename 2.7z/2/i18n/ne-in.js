require('./angular-locale_ne-in');
module.exports = 'ngLocale';
