require('./angular-locale_en-001');
module.exports = 'ngLocale';
