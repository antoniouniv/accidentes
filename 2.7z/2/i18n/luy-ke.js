require('./angular-locale_luy-ke');
module.exports = 'ngLocale';
