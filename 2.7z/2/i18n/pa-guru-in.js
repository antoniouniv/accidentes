require('./angular-locale_pa-guru-in');
module.exports = 'ngLocale';
