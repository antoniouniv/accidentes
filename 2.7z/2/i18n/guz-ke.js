require('./angular-locale_guz-ke');
module.exports = 'ngLocale';
