require('./angular-locale_vai-latn');
module.exports = 'ngLocale';
