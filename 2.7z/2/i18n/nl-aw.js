require('./angular-locale_nl-aw');
module.exports = 'ngLocale';
