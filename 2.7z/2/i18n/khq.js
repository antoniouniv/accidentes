require('./angular-locale_khq');
module.exports = 'ngLocale';
