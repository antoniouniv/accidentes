require('./angular-locale_sk');
module.exports = 'ngLocale';
