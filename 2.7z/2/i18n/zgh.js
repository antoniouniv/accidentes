require('./angular-locale_zgh');
module.exports = 'ngLocale';
