require('./angular-locale_zh-hans-hk');
module.exports = 'ngLocale';
