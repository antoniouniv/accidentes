require('./angular-locale_rm');
module.exports = 'ngLocale';
