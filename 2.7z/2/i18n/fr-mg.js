require('./angular-locale_fr-mg');
module.exports = 'ngLocale';
