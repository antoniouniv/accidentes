require('./angular-locale_yue-hk');
module.exports = 'ngLocale';
