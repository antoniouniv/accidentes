require('./angular-locale_yue');
module.exports = 'ngLocale';
