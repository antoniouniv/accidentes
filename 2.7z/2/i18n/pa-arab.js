require('./angular-locale_pa-arab');
module.exports = 'ngLocale';
