require('./angular-locale_ses-ml');
module.exports = 'ngLocale';
