require('./angular-locale_ar-ss');
module.exports = 'ngLocale';
