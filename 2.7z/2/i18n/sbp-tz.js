require('./angular-locale_sbp-tz');
module.exports = 'ngLocale';
