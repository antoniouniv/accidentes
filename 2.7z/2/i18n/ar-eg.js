require('./angular-locale_ar-eg');
module.exports = 'ngLocale';
