require('./angular-locale_en-fk');
module.exports = 'ngLocale';
